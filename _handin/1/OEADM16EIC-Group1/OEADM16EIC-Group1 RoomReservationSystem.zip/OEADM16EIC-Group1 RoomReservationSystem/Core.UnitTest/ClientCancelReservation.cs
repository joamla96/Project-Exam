﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Core.UnitTest
{

    [TestClass]
    class ClientCancelReservation
    {

    }
}
