﻿using System;

namespace Core.Exceptions
{
    public class NoRoomsAvailableException : Exception
    {

    }
}
