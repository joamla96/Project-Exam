﻿using System;

namespace Mock.Database
{
    public class MockingDatabaseTests
    {
    }
}
