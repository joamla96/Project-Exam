﻿using System;

namespace NotificationSystem
{
    public class ReservationsMonitor:IObserver<Reservation>
    {
    }
}
