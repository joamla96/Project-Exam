﻿using System;

namespace NotificationSystem
{
    public class Class1
    {
    }
}
