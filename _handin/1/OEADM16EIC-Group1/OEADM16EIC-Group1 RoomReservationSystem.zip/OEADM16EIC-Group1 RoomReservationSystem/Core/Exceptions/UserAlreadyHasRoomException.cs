﻿using System;

namespace Core.Exceptions
{
	public class UserAlreadyHasRoomException : Exception
	{
	}
}
